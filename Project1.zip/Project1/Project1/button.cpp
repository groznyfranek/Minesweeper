#include "button.h"
#include <iostream>
Button::Button()
{
	std::cout << "The button has been created\n";
}



Button::~Button()
{
	std::cout << "The button has been erased\n";
}