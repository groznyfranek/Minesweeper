#include "game.h"

int main()
{
    Game g(15, 15, 0.1f);
    g.run();
    return 0;
}