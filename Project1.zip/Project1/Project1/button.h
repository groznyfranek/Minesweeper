#pragma once
#include <SFML/Graphics.hpp>
class Button
{
public:
	Button();
	~Button();
	sf::Texture* texture;
	sf::Sprite* sprite;
};

